package com.aiub.library.repository;

import com.aiub.library.model.Member;

import java.util.List;
import java.util.Optional;

public interface MemberRepository {

    int save(Member member);

    List<Member> findAll();

    Optional<Member> findById(Integer id);
}