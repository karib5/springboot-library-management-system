package com.aiub.library.repository;

import com.aiub.library.model.Member;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class MemberRepositoryImpl implements MemberRepository {

    private final JdbcTemplate jdbcTemplate;

    public MemberRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public int save(Member member) {

        String sql =
                "INSERT INTO members(name,email,phone) VALUES(?,?,?)";

        return jdbcTemplate.update(
                sql,
                member.getName(),
                member.getEmail(),
                member.getPhone()
        );
    }

    @Override
    public List<Member> findAll() {

        String sql = "SELECT * FROM members";

        return jdbcTemplate.query(
                sql,
                (rs, rowNum) -> new Member(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("phone")
                )
        );
    }

    @Override
    public Optional<Member> findById(Integer id) {

        String sql =
                "SELECT * FROM members WHERE id=?";

        List<Member> members =
                jdbcTemplate.query(
                        sql,
                        (rs, rowNum) -> new Member(
                                rs.getInt("id"),
                                rs.getString("name"),
                                rs.getString("email"),
                                rs.getString("phone")
                        ),
                        id
                );

        if (members.isEmpty()) {
            return Optional.empty();
        }

        return Optional.of(members.get(0));
    }
}