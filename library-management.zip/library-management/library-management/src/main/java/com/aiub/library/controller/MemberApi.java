package com.aiub.library.controller;

import com.aiub.library.model.Member;
import com.aiub.library.service.MemberService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/members")
public class MemberApi {

    private final MemberService memberService;

    public MemberApi(MemberService memberService) {
        this.memberService = memberService;
    }

    @PostMapping
    public int save(@RequestBody Member member) {
        return memberService.save(member);
    }

    @GetMapping
    public List<Member> findAll() {
        return memberService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Member> findById(
            @PathVariable Integer id) {

        return memberService.findById(id);
    }
}